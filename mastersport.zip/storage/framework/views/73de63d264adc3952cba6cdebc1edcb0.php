<?php $__env->startSection('title', 'Master Sport | Личный кабинет'); ?>
<?php $__env->startSection('description', 'Простой личный кабинет Master Sport.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container dashboard-grid">
            <article class="panel">
                <h1>Личный кабинет</h1>
                <p>Пока это базовая версия кабинета с ключевой информацией.</p>
                <ul class="profile-list">
                    <li><span>Имя</span><b><?php echo e($user->name); ?></b></li>
                    <li><span>Email</span><b><?php echo e($user->email); ?></b></li>
                    <li><span>Телефон</span><b><?php echo e($user->phone ?: 'Не указан'); ?></b></li>
                </ul>
            </article>

            <article class="panel">
                <h2>Статистика</h2>
                <div class="stats-grid">
                    <div><span>Товары</span><b><?php echo e($productsCount); ?></b></div>
                    <div><span>Категории</span><b><?php echo e($categoriesCount); ?></b></div>
                    <div><span>Коллекции</span><b><?php echo e($collectionsCount); ?></b></div>
                </div>
            </article>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <article class="panel">
                <div class="section-head">
                    <h2>Последние добавленные товары</h2>
                    <a href="<?php echo e(route('catalog')); ?>">В каталог</a>
                </div>

                <?php if($recentProducts->isEmpty()): ?>
                    <p>Товаров пока нет.</p>
                <?php else: ?>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>Название</th>
                                    <th>Категория</th>
                                    <th>Коллекция</th>
                                    <th>Цена</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->category?->name ?? '—'); ?></td>
                                        <td><?php echo e($product->collection?->name ?? '—'); ?></td>
                                        <td><?php echo e(number_format((float) $product->price, 0, ',', ' ')); ?> ₽</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views\dashboard.blade.php ENDPATH**/ ?>