<?php $__env->startSection('title', 'Master Sport | Личный кабинет'); ?>
<?php $__env->startSection('description', 'Личный кабинет: профиль и заказы.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container dashboard-grid">
            <article class="panel profile-panel">
                <?php
                    $avatarLetter = mb_strtoupper(mb_substr($user->name, 0, 1));
                ?>

                <div class="profile-head">
                    <div class="profile-avatar"><?php echo e($avatarLetter); ?></div>
                    <div>
                        <h1>Личный кабинет</h1>
                        <p>Редактируй личные данные и пароль.</p>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('dashboard.profile.update')); ?>" class="profile-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <label class="field">
                        <span>Имя</span>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>
                    </label>

                    <label class="field">
                        <span>Email</span>
                        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required>
                    </label>

                    <label class="field">
                        <span>Телефон</span>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" required>
                    </label>

                    <label class="field">
                        <span>Новый пароль</span>
                        <input type="password" name="password" autocomplete="new-password">
                    </label>

                    <label class="field">
                        <span>Подтверждение пароля</span>
                        <input type="password" name="password_confirmation" autocomplete="new-password">
                    </label>

                    <button class="btn btn-orange" type="submit">Сохранить данные</button>
                </form>
            </article>

            <article class="panel summary-panel">
                <h2>Кратко</h2>
                <div class="stats-grid">
                    <div><span>Активные заказы</span><b><?php echo e($activeOrdersCount); ?></b></div>
                    <div><span>Завершенные</span><b><?php echo e($completedOrdersCount); ?></b></div>
                    <div><span>Товаров в магазине</span><b><?php echo e($productsCount); ?></b></div>
                </div>

                <div class="hero-actions">
                    <a class="btn btn-light" href="<?php echo e(route('catalog')); ?>">Каталог</a>
                    <a class="btn btn-orange" href="<?php echo e(route('cart.index')); ?>">Корзина</a>
                    <?php if($user->isAdmin()): ?>
                        <a class="btn btn-light" href="<?php echo e(route('admin.index')); ?>">Админ</a>
                    <?php endif; ?>
                </div>
            </article>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <article class="panel orders-panel">
                <div class="section-head">
                    <h2>Мои заказы</h2>
                    <span>Всего: <?php echo e($orders->count()); ?></span>
                </div>

                <?php if($errors->has('order')): ?>
                    <p class="order-error"><?php echo e($errors->first('order')); ?></p>
                <?php endif; ?>

                <?php if($orders->isEmpty()): ?>
                    <p>Заказов пока нет.</p>
                <?php else: ?>
                    <?php
                        $statusLabels = [
                            'new' => 'Новый',
                            'processing' => 'В работе',
                            'completed' => 'Завершен',
                            'cancelled' => 'Отменен',
                        ];
                        $deliveryLabels = [
                            'pickup' => 'Самовывоз',
                            'delivery' => 'Доставка',
                        ];
                    ?>

                    <div class="orders-list">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="order-card">
                                <div class="order-top">
                                    <div>
                                        <strong>Заказ #<?php echo e($order->id); ?></strong>
                                        <p><?php echo e($order->created_at?->format('d.m.Y H:i')); ?></p>
                                    </div>
                                    <div class="order-status order-status-<?php echo e($order->status); ?>">
                                        <?php echo e($statusLabels[$order->status] ?? $order->status); ?>

                                    </div>
                                </div>

                                <ul class="order-items">
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="order-item-main">
                                                <div class="order-item-thumb">
                                                    <img
                                                        src="<?php echo e($item->product?->image ? asset('storage/'.$item->product->image) : asset('images/master-sport-banner.png')); ?>"
                                                        alt="<?php echo e($item->product_name); ?>"
                                                    >
                                                </div>
                                                <span><?php echo e($item->product_name); ?> × <?php echo e($item->quantity); ?></span>
                                            </div>
                                            <b><?php echo e(number_format((float) $item->line_total, 0, ',', ' ')); ?> &#8381;</b>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                                <div class="order-delivery">
                                    <p>
                                        <span>Получение:</span>
                                        <b><?php echo e($deliveryLabels[$order->delivery_type] ?? 'Самовывоз'); ?></b>
                                    </p>
                                    <?php if($order->delivery_type === 'delivery'): ?>
                                        <p>
                                            <span>Адрес:</span>
                                            <b><?php echo e($order->delivery_address); ?></b>
                                        </p>
                                    <?php endif; ?>
                                </div>

                                <div class="order-bottom">
                                    <strong>Итого: <?php echo e(number_format((float) $order->total, 0, ',', ' ')); ?> &#8381;</strong>

                                    <?php if(in_array($order->status, ['new', 'processing'], true)): ?>
                                        <form method="POST" action="<?php echo e(route('dashboard.orders.cancel', $order)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-light" type="submit">Отменить заказ</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views/dashboard.blade.php ENDPATH**/ ?>