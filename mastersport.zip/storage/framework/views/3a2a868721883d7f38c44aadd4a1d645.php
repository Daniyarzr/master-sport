<?php
    $cartCount = auth()->check()
        ? \App\Models\CartItem::query()->where('user_id', auth()->id())->sum('quantity')
        : 0;
?>

<div class="site-topline">
    <div class="container site-topline-inner">
        <span>Master Sport · Ижевск</span>
        <span>Ежедневно 09:00-21:00 · +7 (3412) 90-00-00</span>
    </div>
</div>

<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="<?php echo e(route('home')); ?>">
            <span class="brand-mark" aria-hidden="true"><img src="/storage/logo.png" alt="logo"></span>
            <span class="brand-text">Master Sport</span>
        </a>

        <nav class="main-nav" aria-label="Главное меню">
            <a class="<?php echo e(request()->routeIs('home') ? 'is-active' : ''); ?>" href="<?php echo e(route('home')); ?>">Главная</a>
            <a class="<?php echo e(request()->routeIs('catalog') ? 'is-active' : ''); ?>" href="<?php echo e(route('catalog')); ?>">Каталог</a>
            <a class="<?php echo e(request()->routeIs('contacts') ? 'is-active' : ''); ?>" href="<?php echo e(route('contacts')); ?>">Контакты</a>
        </nav>

        <div class="action-group">
            <?php if(auth()->guard()->check()): ?>
                <a
                    class="icon-btn <?php echo e(request()->routeIs('cart.*') ? 'is-active' : ''); ?>"
                    href="<?php echo e(route('cart.index')); ?>"
                    aria-label="Корзина"
                    title="Корзина"
                >
                    <i class="bi bi-cart3" aria-hidden="true"></i>
                    <?php if($cartCount > 0): ?>
                        <span class="icon-badge"><?php echo e($cartCount); ?></span>
                    <?php endif; ?>
                </a>

                <a
                    class="icon-btn <?php echo e(request()->routeIs('dashboard') ? 'is-active' : ''); ?>"
                    href="<?php echo e(route('dashboard')); ?>"
                    aria-label="Личный кабинет"
                    title="Личный кабинет"
                >
                    <i class="bi bi-person-circle" aria-hidden="true"></i>
                </a>

                <?php if(auth()->user()->isAdmin()): ?>
                    <a
                        class="icon-btn <?php echo e(request()->routeIs('admin.*') ? 'is-active' : ''); ?>"
                        href="<?php echo e(route('admin.index')); ?>"
                        aria-label="Админ"
                        title="Админ"
                    >
                        <i class="bi bi-shield-lock" aria-hidden="true"></i>
                    </a>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="icon-btn icon-btn-logout" type="submit" aria-label="Выход" title="Выход">
                        <i class="bi bi-box-arrow-right" aria-hidden="true"></i>
                    </button>
                </form>
            <?php else: ?>
                <a class="btn btn-light" href="<?php echo e(route('login')); ?>">Вход</a>
                <a class="btn btn-dark" href="<?php echo e(route('register')); ?>">Регистрация</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH D:\Колледж\Практика\master-sport\resources\views/partials/header.blade.php ENDPATH**/ ?>