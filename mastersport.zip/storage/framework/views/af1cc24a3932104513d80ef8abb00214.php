<?php $__env->startSection('title', 'Master Sport'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container">
            <article class="panel">
                <h1>Master Sport</h1>
                <p>Стартовая страница проекта. Основной контент доступен на главной и в каталоге.</p>
                <div class="hero-actions">
                    <a class="btn btn-dark" href="<?php echo e(route('home')); ?>">На главную</a>
                    <a class="btn btn-light" href="<?php echo e(route('catalog')); ?>">В каталог</a>
                </div>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views\welcome.blade.php ENDPATH**/ ?>