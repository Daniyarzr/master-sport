<?php $__env->startSection('title', 'Master Sport | Вход'); ?>
<?php $__env->startSection('description', 'Вход в личный кабинет Master Sport.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container auth-wrap">
            <article class="panel auth-card">
                <h1>Вход</h1>
                <p>Войди в кабинет, чтобы смотреть данные профиля и состояние магазина.</p>

                <form method="POST" action="<?php echo e(url('/login')); ?>" class="auth-form">
                    <?php echo csrf_field(); ?>
                    <label class="field">
                        <span>Email</span>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                    </label>

                    <label class="field">
                        <span>Пароль</span>
                        <input type="password" name="password" required autocomplete="current-password">
                    </label>

                    <label class="check">
                        <input type="checkbox" name="remember">
                        <span>Запомнить меня</span>
                    </label>

                    <button class="btn btn-dark" type="submit">Войти</button>
                </form>

                <p class="auth-meta">
                    Нет аккаунта?
                    <a href="<?php echo e(route('register')); ?>">Создать</a>
                </p>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views/auth/login.blade.php ENDPATH**/ ?>