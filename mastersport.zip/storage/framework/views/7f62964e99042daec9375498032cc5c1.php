<?php $__env->startSection('title', 'Master Sport | Каталог'); ?>
<?php $__env->startSection('description', 'Каталог Master Sport: футболки, шорты, худи и коллекции.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container catalog-layout">
            <aside class="panel filter-panel">
                <h2>Фильтры</h2>
                <form method="GET" action="<?php echo e(route('catalog')); ?>" class="filter-form">
                    <label class="field">
                        <span>Поиск</span>
                        <input
                            type="text"
                            name="search"
                            value="<?php echo e($filters['search']); ?>"
                            placeholder="Например: худи, футболка..."
                        >
                    </label>

                    <label class="field">
                        <span>Категория</span>
                        <select name="category">
                            <option value="">Все категории</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if((string) $category->id === $filters['category']): echo 'selected'; endif; ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label class="field">
                        <span>Коллекция</span>
                        <select name="collection">
                            <option value="">Все коллекции</option>
                            <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($collection->id); ?>" <?php if((string) $collection->id === $filters['collection']): echo 'selected'; endif; ?>>
                                    <?php echo e($collection->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label class="field">
                        <span>Цена от</span>
                        <input
                            type="number"
                            name="price_from"
                            min="0"
                            step="1"
                            value="<?php echo e($filters['price_from']); ?>"
                            placeholder="0"
                        >
                    </label>

                    <label class="field">
                        <span>Цена до</span>
                        <input
                            type="number"
                            name="price_to"
                            min="0"
                            step="1"
                            value="<?php echo e($filters['price_to']); ?>"
                            placeholder="10000"
                        >
                    </label>

                    <div class="filter-actions">
                        <button class="btn btn-orange" type="submit">Применить</button>
                        <a class="btn btn-light" href="<?php echo e(route('catalog')); ?>">Сбросить</a>
                    </div>
                </form>
            </aside>

            <div class="catalog-content">
                <div class="section-head">
                    <h2>Каталог товаров</h2>
                    <span>Показано: <?php echo e($products->count()); ?></span>
                </div>

                <?php if($products->isEmpty()): ?>
                    <div class="panel empty-state">
                        По текущим фильтрам товаров не найдено.
                    </div>
                <?php else: ?>
                    <div class="product-grid">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="panel product-card">
                                <div class="product-media">
                                    <img
                                        src="<?php echo e($product->image ? asset('storage/'.$product->image) : asset('images/master-sport-banner.png')); ?>"
                                        alt="<?php echo e($product->name); ?>"
                                    >
                                </div>
                                <div class="product-card-body">
                                    <div class="product-card-top">
                                        <strong><?php echo e($product->name); ?></strong>
                                    </div>
                                    <p><?php echo e($product->description ?: 'Описание скоро добавим.'); ?></p>
                                    <div class="meta-row">
                                        <span><?php echo e($product->category?->name ?? 'Без категории'); ?></span>
                                        <span><?php echo e($product->collection?->name ?? 'Без коллекции'); ?></span>
                                        <span>Остаток: <?php echo e($product->stock); ?></span>
                                    </div>

                                    <?php if(auth()->guard()->check()): ?>
                                        <div class="product-buy-row">
                                            <b class="product-price-inline"><?php echo e(number_format((float) $product->price, 0, ',', ' ')); ?> ₽</b>
                                            <form method="POST" action="<?php echo e(route('cart.add', $product)); ?>" class="cart-inline-form">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="quantity" value="1">
                                                <button class="btn btn-orange cart-add-btn" type="submit" <?php if($product->stock < 1): echo 'disabled'; endif; ?>>
                                                    <i class="bi bi-plus-lg" aria-hidden="true"></i>
                                                    <span><?php echo e($product->stock < 1 ? 'Нет в наличии' : 'В корзину'); ?></span>
                                                </button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                        <div class="product-buy-row">
                                            <b class="product-price-inline"><?php echo e(number_format((float) $product->price, 0, ',', ' ')); ?> ₽</b>
                                            <a class="btn btn-light cart-inline-link" href="<?php echo e(route('login')); ?>">Войти для покупки</a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="pager">
                        <?php if($products->previousPageUrl()): ?>
                            <a class="btn btn-light" href="<?php echo e($products->previousPageUrl()); ?>">Назад</a>
                        <?php endif; ?>
                        <?php if($products->nextPageUrl()): ?>
                            <a class="btn btn-light" href="<?php echo e($products->nextPageUrl()); ?>">Дальше</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views/catalog.blade.php ENDPATH**/ ?>