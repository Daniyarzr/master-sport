<?php $__env->startSection('title', 'Master Sport | Регистрация'); ?>
<?php $__env->startSection('description', 'Регистрация в Master Sport: имя, email и телефон.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container auth-wrap">
            <article class="panel auth-card">
                <h1>Регистрация</h1>
                <p>Создай аккаунт для работы с личным кабинетом.</p>

                <form method="POST" action="<?php echo e(route('register.store')); ?>" class="auth-form">
                    <?php echo csrf_field(); ?>
                    <label class="field">
                        <span>Имя</span>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name">
                    </label>

                    <label class="field">
                        <span>Email</span>
                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                    </label>

                    <label class="field">
                        <span>Телефон</span>
                        <input
                            type="text"
                            name="phone"
                            value="<?php echo e(old('phone')); ?>"
                            required
                            autocomplete="tel"
                            placeholder="+79001234567"
                        >
                    </label>

                    <label class="field">
                        <span>Пароль</span>
                        <input type="password" name="password" required autocomplete="new-password">
                    </label>

                    <label class="field">
                        <span>Подтверждение пароля</span>
                        <input type="password" name="password_confirmation" required autocomplete="new-password">
                    </label>

                    <button class="btn btn-dark" type="submit">Зарегистрироваться</button>
                </form>

                <p class="auth-meta">
                    Уже есть аккаунт?
                    <a href="<?php echo e(route('login')); ?>">Войти</a>
                </p>
            </article>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views/auth/register.blade.php ENDPATH**/ ?>