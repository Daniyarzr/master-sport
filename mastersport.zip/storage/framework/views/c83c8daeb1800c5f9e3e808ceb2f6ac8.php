<?php $__env->startSection('title', 'Master Sport | Главная'); ?>
<?php $__env->startSection('description', 'Master Sport: стильная спортивная одежда, коллекции и новинки.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section banner-section">
        <div class="container">
            <article class="hero-banner hero-banner-compact">
                <img
                    src="<?php echo e(asset('images/master-sport-banner.png')); ?>"
                    alt="Баннер Master Sport"
                    class="hero-banner-image"
                >
                <div class="hero-banner-overlay"></div>
                <div class="hero-banner-content">
                    <span class="eyebrow">Новая коллекция · 2026</span>
                    <h1>Твой ритм. Твой стиль. Твой Master Sport.</h1>
                    <p>Футболки, шорты и худи в фирменной палитре с оранжевыми акцентами.</p>
                    <div class="hero-actions">
                        <a class="btn btn-orange" href="<?php echo e(route('catalog')); ?>">Смотреть каталог</a>
                        <?php if(auth()->guard()->check()): ?>
                            <a class="btn btn-light" href="<?php echo e(route('cart.index')); ?>">Моя корзина</a>
                        <?php else: ?>
                            <a class="btn btn-light" href="<?php echo e(route('login')); ?>">Войти и покупать</a>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div class="section-head">
                <h2>Почему выбирают нас</h2>
                <a href="<?php echo e(route('catalog')); ?>">Перейти к товарам</a>
            </div>

            <div class="story-grid">
                <article class="panel story-card">
                    <h3>Технологичные ткани</h3>
                    <p>Материалы, которые дышат и держат форму после активных тренировок и частой стирки.</p>
                </article>
                <article class="panel story-card">
                    <h3>Нормальная посадка</h3>
                    <p>Модели рассчитаны под движение: удобно в зале, на улице и в ежедневном ритме.</p>
                </article>
                <article class="panel story-card">
                    <h3>Честные остатки</h3>
                    <p>Остатки по складу и заказы в личном кабинете обновляются в реальном времени.</p>
                </article>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div class="section-head">
                <h2>Новинки</h2>
                <a href="<?php echo e(route('catalog')); ?>">Открыть весь каталог</a>
            </div>

            <div class="product-grid product-grid-home">
                <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="panel product-card">
                        <div class="product-media">
                            <img
                                src="<?php echo e($product->image ? asset('storage/'.$product->image) : asset('images/master-sport-banner.png')); ?>"
                                alt="<?php echo e($product->name); ?>"
                            >
                        </div>
                        <div class="product-card-body">
                            <div class="product-card-top">
                                <strong><?php echo e($product->name); ?></strong>
                            </div>
                            <p><?php echo e($product->description ?: 'Описание скоро добавим.'); ?></p>
                            <div class="meta-row">
                                <span><?php echo e($product->category?->name ?? 'Без категории'); ?></span>
                                <span><?php echo e($product->collection?->name ?? 'Без коллекции'); ?></span>
                                <span>Остаток: <?php echo e($product->stock); ?></span>
                            </div>

                            <?php if(auth()->guard()->check()): ?>
                                <div class="product-buy-row">
                                    <b class="product-price-inline"><?php echo e(number_format((float) $product->price, 0, ',', ' ')); ?> ₽</b>
                                    <form method="POST" action="<?php echo e(route('cart.add', $product)); ?>" class="cart-inline-form">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="quantity" value="1">
                                        <button class="btn btn-orange cart-add-btn" type="submit" <?php if($product->stock < 1): echo 'disabled'; endif; ?>>
                                            <i class="bi bi-plus-lg" aria-hidden="true"></i>
                                            <span><?php echo e($product->stock < 1 ? 'Нет в наличии' : 'В корзину'); ?></span>
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <div class="product-buy-row">
                                    <b class="product-price-inline"><?php echo e(number_format((float) $product->price, 0, ',', ' ')); ?> ₽</b>
                                    <a class="btn btn-light cart-inline-link" href="<?php echo e(route('login')); ?>">Войти для покупки</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <article class="panel empty-state">
                        Товаров пока нет. Запусти сидер, чтобы загрузить демонстрационные позиции.
                    </article>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div class="section-head">
                <h2>Коллекции</h2>
                <a href="<?php echo e(route('catalog')); ?>">Смотреть товары</a>
            </div>

            <div class="collection-grid">
                <?php $__empty_1 = true; $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="panel collection-card">
                        <h3><?php echo e($collection->name); ?></h3>
                        <p><?php echo e($collection->description ?: 'Коллекция без описания.'); ?></p>
                        <span><?php echo e($collection->products_count); ?> товаров</span>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <article class="panel collection-card">
                        <h3>Коллекций пока нет</h3>
                        <p>Добавь данные через сидер, чтобы заполнить витрину.</p>
                        <span>0 товаров</span>
                    </article>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views/home.blade.php ENDPATH**/ ?>