<div class="site-topline">
    <div class="container site-topline-inner">
        <span>Master Sport · Ижевск</span>
        <span>Ежедневно 09:00-21:00 · +7 (3412) 90-00-00</span>
    </div>
</div>

<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="<?php echo e(route('home')); ?>">
            <span class="brand-mark" aria-hidden="true">MS</span>
            <span class="brand-text">Master Sport</span>
        </a>

        <nav class="main-nav" aria-label="Главное меню">
            <a class="<?php echo e(request()->routeIs('home') ? 'is-active' : ''); ?>" href="<?php echo e(route('home')); ?>">Главная</a>
            <a class="<?php echo e(request()->routeIs('catalog') ? 'is-active' : ''); ?>" href="<?php echo e(route('catalog')); ?>">Каталог</a>
            <a class="<?php echo e(request()->routeIs('contacts') ? 'is-active' : ''); ?>" href="<?php echo e(route('contacts')); ?>">Контакты</a>
        </nav>

        <div class="action-group">
            <?php if(auth()->guard()->check()): ?>
                <a class="btn btn-light" href="<?php echo e(route('dashboard')); ?>">Личный кабинет</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-dark" type="submit">Выход</button>
                </form>
            <?php else: ?>
                <a class="btn btn-light" href="<?php echo e(route('login')); ?>">Вход</a>
                <a class="btn btn-dark" href="<?php echo e(route('register')); ?>">Регистрация</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<?php /**PATH D:\Колледж\Практика\master-sport\resources\views\partials\header.blade.php ENDPATH**/ ?>