<?php $__env->startSection('title', 'Master Sport | Корзина'); ?>
<?php $__env->startSection('description', 'Корзина и оформление заказа Master Sport.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container cart-layout">
            <article class="panel cart-panel">
                <div class="section-head">
                    <h1>Корзина</h1>
                    <?php if($items->isNotEmpty()): ?>
                        <form method="POST" action="<?php echo e(route('cart.clear')); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-light" type="submit">Очистить</button>
                        </form>
                    <?php endif; ?>
                </div>

                <?php if($items->isEmpty()): ?>
                    <p>В корзине пока пусто. Добавь товары из каталога.</p>
                    <div class="hero-actions">
                        <a class="btn btn-orange" href="<?php echo e(route('catalog')); ?>">Перейти в каталог</a>
                    </div>
                <?php else: ?>
                    <div class="cart-items">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="cart-item">
                                <div class="cart-item-image">
                                    <img
                                        src="<?php echo e($item['image'] ? asset('storage/'.$item['image']) : asset('images/master-sport-banner.png')); ?>"
                                        alt="<?php echo e($item['name']); ?>"
                                    >
                                </div>

                                <div class="cart-item-body">
                                    <h3><?php echo e($item['name']); ?></h3>
                                    <p><?php echo e(number_format((float) $item['price'], 0, ',', ' ')); ?> &#8381; за шт.</p>
                                    <p>В наличии: <?php echo e($item['stock']); ?></p>

                                    <div class="cart-item-actions">
                                        <div class="cart-qty-control">
                                            <?php if((int) $item['quantity'] > 1): ?>
                                                <form method="POST" action="<?php echo e(route('cart.update', $item['product_id'])); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="quantity" value="<?php echo e((int) $item['quantity'] - 1); ?>">
                                                    <button class="qty-btn" type="submit" aria-label="Уменьшить">−</button>
                                                </form>
                                            <?php else: ?>
                                                <form method="POST" action="<?php echo e(route('cart.remove', $item['product_id'])); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="qty-btn" type="submit" aria-label="Удалить">−</button>
                                                </form>
                                            <?php endif; ?>

                                            <span class="qty-value"><?php echo e($item['quantity']); ?></span>

                                            <form method="POST" action="<?php echo e(route('cart.add', $item['product_id'])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="quantity" value="1">
                                                <button class="qty-btn" type="submit" aria-label="Увеличить" <?php if((int) $item['quantity'] >= (int) $item['stock']): echo 'disabled'; endif; ?>>+</button>
                                            </form>
                                        </div>

                                        <form method="POST" action="<?php echo e(route('cart.remove', $item['product_id'])); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-light" type="submit">Удалить</button>
                                        </form>
                                    </div>
                                </div>

                                <div class="cart-item-total">
                                    <?php echo e(number_format((float) $item['line_total'], 0, ',', ' ')); ?> &#8381;
                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </article>

            <aside class="panel checkout-panel">
                <h2>Оформление</h2>

                <div class="checkout-total-lines">
                    <p>Товары: <strong><?php echo e(number_format((float) $itemsTotal, 0, ',', ' ')); ?> &#8381;</strong></p>
                    <p>Самовывоз: <strong>0 &#8381;</strong></p>
                    <p>Доставка: <strong><?php echo e(number_format((float) $deliveryPrice, 0, ',', ' ')); ?> &#8381;</strong></p>
                </div>

                <?php if($items->isEmpty()): ?>
                    <p>Сначала добавь товары в корзину.</p>
                <?php else: ?>
                    <?php
                        $selectedDeliveryType = old('delivery_type', 'pickup');
                    ?>

                    <form method="POST" action="<?php echo e(route('cart.checkout')); ?>" class="checkout-form checkout-delivery-form">
                        <?php echo csrf_field(); ?>

                        <label class="field">
                            <span>Имя</span>
                            <input type="text" name="customer_name" value="<?php echo e(old('customer_name', $user->name)); ?>" required>
                        </label>

                        <label class="field">
                            <span>Email</span>
                            <input type="email" name="customer_email" value="<?php echo e(old('customer_email', $user->email)); ?>" required>
                        </label>

                        <label class="field">
                            <span>Телефон</span>
                            <input type="text" name="customer_phone" value="<?php echo e(old('customer_phone', $user->phone)); ?>" required>
                        </label>

                        <div class="field">
                            <span>Способ получения</span>
                            <div class="delivery-cards">
                                <label class="delivery-card">
                                    <input type="radio" name="delivery_type" value="pickup" <?php if($selectedDeliveryType === 'pickup'): echo 'checked'; endif; ?>>
                                    <span class="delivery-card-box">
                                        <span class="delivery-check" aria-hidden="true"></span>
                                        <span class="delivery-card-text">
                                            <b>Самовывоз</b>
                                            <small><?php echo e($pickupAddress); ?></small>
                                        </span>
                                    </span>
                                </label>

                                <label class="delivery-card">
                                    <input type="radio" name="delivery_type" value="delivery" <?php if($selectedDeliveryType === 'delivery'): echo 'checked'; endif; ?>>
                                    <span class="delivery-card-box">
                                        <span class="delivery-check" aria-hidden="true"></span>
                                        <span class="delivery-card-text">
                                            <b>Доставка</b>
                                            <small><?php echo e(number_format((float) $deliveryPrice, 0, ',', ' ')); ?> &#8381;</small>
                                        </span>
                                    </span>
                                </label>
                            </div>
                        </div>

                        <label class="field delivery-address-field <?php if($selectedDeliveryType === 'delivery'): ?> is-visible <?php endif; ?>">
                            <span>Адрес доставки</span>
                            <input type="text" name="delivery_address" value="<?php echo e(old('delivery_address')); ?>">
                        </label>

                        <label class="field">
                            <span>Комментарий</span>
                            <textarea name="comment" rows="4"><?php echo e(old('comment')); ?></textarea>
                        </label>

                        <button class="btn btn-orange" type="submit">Оформить заказ</button>
                    </form>
                <?php endif; ?>
            </aside>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views/cart/index.blade.php ENDPATH**/ ?>