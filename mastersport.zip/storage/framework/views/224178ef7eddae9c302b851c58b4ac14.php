<footer class="site-footer">
    <div class="container footer-inner">
        <div>
            <strong>Master Sport</strong>
            <p>Спортивная одежда на каждый день: футболки, шорты, худи и сезонные коллекции.</p>
        </div>

        <div class="footer-links">
            <a href="<?php echo e(route('catalog')); ?>">Каталог</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('cart.index')); ?>">Корзина</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Корзина</a>
            <?php endif; ?>
            <a href="<?php echo e(route('contacts')); ?>">Контакты</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>">ЛК</a>
            <?php else: ?>
                <a href="<?php echo e(route('register')); ?>">Регистрация</a>
            <?php endif; ?>
        </div>
    </div>
</footer>
<?php /**PATH D:\Колледж\Практика\master-sport\resources\views/partials/footer.blade.php ENDPATH**/ ?>