<?php $__env->startSection('title', 'Master Sport | Главная'); ?>
<?php $__env->startSection('description', 'Master Sport: базовая спортивная одежда и сезонные коллекции.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section hero-section">
        <div class="container hero-grid">
            <article class="panel hero-panel">
                <p class="eyebrow">Новая поставка · Весна 2026</p>
                <h1>Нормальная спортивная база без лишнего.</h1>
                <p>
                    Собрали повседневные модели, которые удобно носить и в зал, и в городе:
                    футболки, шорты, худи и верхние слои. Акцент на посадку, ткань и спокойные цвета.
                </p>
                <div class="hero-actions">
                    <a class="btn btn-dark" href="<?php echo e(route('catalog')); ?>">Открыть каталог</a>
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="btn btn-light" href="<?php echo e(route('register')); ?>">Создать аккаунт</a>
                    <?php endif; ?>
                </div>
            </article>

            <aside class="panel side-panel">
                <h2>Новинки недели</h2>
                <ul class="side-list">
                    <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li>
                            <div>
                                <strong><?php echo e($product->name); ?></strong>
                                <span><?php echo e($product->category?->name ?? 'Без категории'); ?></span>
                            </div>
                            <b><?php echo e(number_format((float) $product->price, 0, ',', ' ')); ?> ₽</b>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li>
                            <div>
                                <strong>Товаров пока нет</strong>
                                <span>Запусти сидер, чтобы загрузить тестовые позиции.</span>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </aside>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div class="section-head">
                <h2>Коллекции</h2>
                <a href="<?php echo e(route('catalog')); ?>">Смотреть все товары</a>
            </div>

            <div class="collection-grid">
                <?php $__empty_1 = true; $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="panel collection-card">
                        <h3><?php echo e($collection->name); ?></h3>
                        <p><?php echo e($collection->description ?: 'Коллекция без описания.'); ?></p>
                        <span><?php echo e($collection->products_count); ?> товаров</span>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <article class="panel collection-card">
                        <h3>Коллекций пока нет</h3>
                        <p>Добавь данные через сидер, чтобы заполнить витрину.</p>
                        <span>0 товаров</span>
                    </article>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Колледж\Практика\master-sport\resources\views\home.blade.php ENDPATH**/ ?>